import threading
import webview
import uvicorn

def start_fastapi():
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, log_level="info")

# Run FastAPI in background
threading.Thread(target=start_fastapi, daemon=True).start()

# Open a native desktop window
webview.create_window("AI MEDVISION", "http://127.0.0.1:8000", width=800, height=600)
webview.start()