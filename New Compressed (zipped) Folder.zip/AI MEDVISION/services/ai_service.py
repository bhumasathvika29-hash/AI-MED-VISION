import math

# 🏥 HOSPITAL DATABASE
HOSPITALS = [
    {"name": "Gandhi General Hospital", "lat": 17.4243, "lon": 78.5034, "phone": "040-27505566"},
    {"name": "Osmania General Hospital", "lat": 17.3783, "lon": 78.4812, "phone": "040-24600121"},
    {"name": "Apollo Health City", "lat": 17.4156, "lon": 78.4111, "phone": "040-23607777"},
    {"name": "Rural PHC Center A", "lat": 17.5600, "lon": 78.4500, "phone": "108"}
]

def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371 
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2)**2 + 
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lon / 2)**2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def check_emergency(symptoms):
    """Initial check to see if we should trigger a risk alert immediately"""
    emergency_keywords = ["chest pain", "breathing difficulty", "unconscious", "severe bleeding", "heart attack"]
    text = " ".join(symptoms).lower()
    return any(keyword in text for keyword in emergency_keywords)

def analyze_with_ai(symptoms, h_data):
    text = " ".join(symptoms).lower()
    
    # Matches requirements for Emergency Hub in script.js
    base_res = {
        "hospital": h_data["name"], 
        "h_phone": h_data["phone"], 
        "h_dist": h_data["dist"],
        "h_lat": h_data["lat"], 
        "h_lon": h_data["lon"]
    }

    # 🚨 RISK ALERT: EMERGENCY (Triggers Siren)
    if "chest pain" in text or "heart attack" in text:
        msg = f"🚨 RISK ALERT: HEART ISSUE SUSPECTED! Go to {h_data['name']} immediately."
        return {
            **base_res,
            "severity": "EMERGENCY",
            "analysis": msg,
            "voice_advice": "Emergency detected. Chest pain risk. Sit down and call for help immediately.",
            "first_aid": ["Sit down", "Loosen tight clothes", "Call 108"]
        }

    if "breathing difficulty" in text:
        msg = "🚨 RISK ALERT: BREATHING EMERGENCY! Seek oxygen support immediately."
        return {
            **base_res,
            "severity": "EMERGENCY",
            "analysis": msg,
            "voice_advice": "Emergency. Breathing difficulty. Sit upright and get fresh air.",
            "first_aid": ["Sit upright", "Open windows", "Do not lie flat"]
        }

    # ⚠️ HIGH RISK (No Siren, Red UI)
    if "high fever" in text or "high bp" in text or "high sugar" in text:
        msg = "High Risk: Serious symptoms detected. Please visit a doctor soon."
        return {
            **base_res,
            "severity": "HIGH",
            "analysis": msg,
            "voice_advice": "High risk symptoms detected. Please monitor closely."
        }

    # ✅ LOW RISK
    msg = "Condition appears mild. Rest and monitor your symptoms."
    return {
        **base_res,
        "severity": "LOW",
        "analysis": msg,
        "voice_advice": "Mild symptoms. Take rest."
    }