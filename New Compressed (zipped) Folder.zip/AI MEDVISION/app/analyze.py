from fastapi import APIRouter
from pydantic import BaseModel
from app.services.ai_service import analyze_with_ai
from app.services.emergency_checker import check_emergency

router = APIRouter()

class SymptomRequest(BaseModel):
    symptoms: list[str]

@router.post("/analyze")
def analyze(data: SymptomRequest):
    if check_emergency(data.symptoms):
        return {
            "status": "EMERGENCY",
            "message": "Seek medical help immediately"
        }

    result = analyze_with_ai(data.symptoms)
    return {
        "status": "NON-EMERGENCY",
        "analysis": result
    }