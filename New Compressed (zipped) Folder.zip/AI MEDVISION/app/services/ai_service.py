def analyze_with_ai(symptoms):
    return f"AI analysis for: {', '.join(symptoms)}"