def check_emergency(symptoms):
    emergency_keywords = [
        "chest pain",
        "breathing difficulty",
        "unconscious",
        "severe bleeding",
        "heart attack"
    ]
    return any(symptom.lower() in emergency_keywords for symptom in symptoms)