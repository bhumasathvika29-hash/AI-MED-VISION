from fastapi import FastAPI, Request, Body, File, UploadFile
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import math

BASE_DIR = Path(__file__).resolve().parent.parent

app = FastAPI()

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# 🏥 HOSPITAL DATABASE
HOSPITALS = [
    {"name": "Gandhi General Hospital", "lat": 17.4243, "lon": 78.5034, "phone": "040-27505566"},
    {"name": "Osmania General Hospital", "lat": 17.3783, "lon": 78.4812, "phone": "040-24600121"},
    {"name": "Apollo Health City", "lat": 17.4156, "lon": 78.4111, "phone": "040-23607777"},
    {"name": "Rural PHC Center A", "lat": 17.5600, "lon": 78.4500, "phone": "108"}
]

# 📏 GEOSPATIAL MATH
def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371 
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2)**2 + 
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lon / 2)**2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

# 🚨 EMERGENCY CHECK
def check_emergency(symptoms):
    emergency_keywords = ["chest pain", "breathing difficulty", "unconscious", "severe bleeding", "heart attack", "low bp", "high sugar", "high bp"]
    text = " ".join(symptoms).lower()
    return any(keyword in text for keyword in emergency_keywords)

# 🧠 SMART ANALYSIS ENGINE
def analyze_with_ai(symptoms, h_data):
    text = " ".join(symptoms).lower()
    
    base_res = {
        "hospital": h_data["name"], 
        "h_phone": h_data["phone"], 
        "h_dist": h_data["dist"],
        "h_lat": h_data["lat"], 
        "h_lon": h_data["lon"]
    }

    if "chest pain" in text:
        msg = f"🚨 EMERGENCY: Possible heart problem! Proceed to {h_data['name']} immediately."
        return {**base_res, "severity": "EMERGENCY", "analysis": msg, "voice_advice": msg}

    if "breathing difficulty" in text:
        msg = "🚨 EMERGENCY: Breathing difficulty detected. Sit upright and get fresh air."
        return {**base_res, "severity": "EMERGENCY", "analysis": msg, "voice_advice": msg}

    if "high fever" in text:
        msg = f"High fever detected. Monitor temperature and visit {h_data['name']} if it persists."
        return {**base_res, "severity": "HIGH", "analysis": msg, "voice_advice": msg}

    if any(term in text for term in ["high sugar", "diabetes"]):
        msg = "Blood sugar imbalance suspected. Please test your sugar levels."
        return {**base_res, "severity": "HIGH", "analysis": msg, "voice_advice": msg}

    if "low bp" in text or "fainting" in text:
        msg = "Possible Low Blood Pressure. Lie down, elevate your legs, and drink fluids."
        return {**base_res, "severity": "MEDIUM", "analysis": msg, "voice_advice": msg}

    msg = "Symptoms appear mild. Please rest and monitor your condition."
    return {**base_res, "severity": "LOW", "analysis": msg, "voice_advice": msg}

# HOME PAGE
@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# ✅ ANALYZE ENDPOINT
@app.post("/analyze")
async def analyze(data = Body(...)):
    user_lat = data.get("lat", 0)
    user_lon = data.get("lon", 0)
    symptoms = data.get("symptoms", [])

    # Find nearest hospital
    nearest = min(HOSPITALS, key=lambda h: calculate_distance(user_lat, user_lon, h['lat'], h['lon']))
    dist = round(calculate_distance(user_lat, user_lon, nearest['lat'], nearest['lon']), 1)
    
    h_info = {
        "name": nearest["name"], 
        "phone": nearest["phone"], 
        "dist": dist, 
        "lat": nearest["lat"], 
        "lon": nearest["lon"]
    }

    # 1. First, check for immediate emergency keywords to trigger the SIREN
    if check_emergency(symptoms):
        msg = f"🚨 RISK ALERT: Life-threatening condition! Proceed to {h_info['name']} immediately."
        return {
            "severity": "EMERGENCY", 
            "analysis": msg,
            "voice_advice": msg,
            "hospital": h_info["name"],
            "h_phone": h_info["phone"],
            "h_dist": h_info["dist"],
            "h_lat": h_info["lat"],
            "h_lon": h_info["lon"]
        }

    # 2. Otherwise, run the detailed AI analysis
    return analyze_with_ai(symptoms, h_info)

# 💊 VISION AI ENDPOINT
@app.post("/scan-medicine")
async def scan_medicine(file: UploadFile = File(...)):
    return {
        "tablet_name": "Paracetamol 500mg",
        "info": "Medicine identified: Paracetamol 500mg. Usage: Used for fever and mild pain."
    }

# FAVICON
@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return {"status": "ok"}