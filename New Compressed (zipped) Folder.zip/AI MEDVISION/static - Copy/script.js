const startBtn = document.getElementById("start-btn");
const analyzeBtn = document.getElementById("analyze-btn");
const symptomsList = document.getElementById("symptoms-list");
const resultDiv = document.getElementById("result");

let symptoms = [];

// Voice input using Web Speech API
startBtn.onclick = () => {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        symptoms.push(transcript);

        const li = document.createElement("li");
        li.textContent = transcript;
        symptomsList.appendChild(li);

        // Check emergency keywords immediately
        const emergencyKeywords = ["chest pain", "breathing difficulty", "unconscious"];
        if (emergencyKeywords.some(k => transcript.toLowerCase().includes(k))) {
            alert("🚨 EMERGENCY DETECTED! Seek medical help immediately!");
        }
    };
};

// Analyze button
analyzeBtn.onclick = async () => {
    if (symptoms.length === 0) return alert("Speak some symptoms first!");

    const response = await fetch("/analyze", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(symptoms)
    });

    const data = await response.json();
    resultDiv.textContent = JSON.stringify(data, null, 2);
};